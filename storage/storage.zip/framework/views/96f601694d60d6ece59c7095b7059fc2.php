<div>

    <div class="p-4 text-left">
        
        <p class="text-gray-500"><?php echo e(now()->locale('id')->translatedFormat('l, d F Y')); ?></p>

        <div id="mainTimerContainer" style="display: <?php echo e($isLemburRunning ? 'none' : 'block'); ?>;">
            
            <h1 id="timerDisplay"
                class="font-bold text-center 
                    text-4xl sm:text-6xl lg:text-8xl   
                    py-2 sm:py-4">
                
                00:00:00
            </h1>
        </div>

        <div id="lemburContainer" style="display: <?php echo e($isLemburRunning ? 'block' : 'none'); ?>;">
            
            <h1 id="lemburDisplay"
                class="font-bold text-center 
                    text-3xl sm:text-5xl lg:text-6xl 
                    text-yellow-500 
                    bg-gray-100 
                    py-2 sm:py-4 
                    rounded-md 
                    shadow-md">
                00:00:00
            </h1>
        </div>

        <div class="p-10 text-center">
            
            <button id="startButton" wire:click="$set('showStartModal', true)"
                class="px-6 py-2 font-bold rounded 
                <?php echo e($timeOut ? 'bg-gray-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700 text-white'); ?>"
                style="display: <?php echo e($isRunning ? 'none' : 'inline-block'); ?>" <?php echo e($timeOut ? 'disabled' : ''); ?>>
                Mulai
            </button>

            
            <button id="stopButton" wire:click="$set('showStopModal', true)"
                class="px-6 py-2 font-bold rounded 
                <?php echo e(!$isRunning || $timeOut ? 'bg-gray-600 cursor-not-allowed' : 'bg-red-600 hover:bg-red-700 text-white'); ?>"
                style="display: <?php echo e($isRunning ? 'inline-block' : 'none'); ?>"
                <?php echo e(!$isRunning || $timeOut ? 'disabled' : ''); ?>>
                Selesai
            </button>

            
            <button id="dinasKeluarButton" wire:click="$set('showDinasModal', true)"
                class="px-6 py-2 font-bold rounded 
                bg-blue-600 hover:bg-blue-700 text-white">
                Dinas Luar
            </button>
            
            <button wire:click="openLemburModal"
                class="px-6 py-2 font-bold rounded bg-yellow-500 hover:bg-yellow-700 text-white"
                style="display: <?php echo e(!$isLemburRunning && $timeOut ? 'inline-block' : 'none'); ?>">
                Mulai Lembur
            </button>

            
            <button wire:click="stopLemburMandiri"
                class="px-6 py-2 font-bold rounded bg-red-500 hover:bg-red-700 text-white"
                style="display: <?php echo e($isLemburRunning ? 'inline-block' : 'none'); ?>">
                Selesai Lembur
            </button>
        </div>

        
        <!--[if BLOCK]><![endif]--><?php if($showStartModal): ?>
            <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
                <div class="bg-white p-6 rounded-md w-96">
                    <h2 class="text-xl font-bold mb-4">Mulai Timer</h2>
                    <textarea wire:model.defer="deskripsi_in" class="w-full p-2 border rounded-md"
                        placeholder="Masukkan deskripsi pekerjaan..."></textarea>
                    <div class="mt-4 flex justify-end gap-2">
                        <button wire:click="$set('showStartModal', false)"
                            class="px-4 py-2 bg-gray-400 text-white rounded-md hover:bg-gray-500">Batal</button>
                        <button wire:click="startTimer"
                            class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Mulai</button>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if($showStopModal): ?>
            <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
                <div class="bg-white p-6 rounded-md w-96">
                    <h2 class="text-xl font-bold mb-4">Selesai Timer</h2>
                    <textarea wire:model.defer="deskripsi_out" class="w-full p-2 border rounded-md"
                        placeholder="Masukkan hasil pekerjaan..."></textarea>
                    <div class="mt-4 flex justify-end gap-2">
                        <button wire:click="$set('showStopModal', false)"
                            class="px-4 py-2 bg-gray-400 text-white rounded-md hover:bg-gray-500">Batal</button>
                        <button wire:click="openWorkReportModal"
                            class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">Selesai</button>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if($showDinasModal): ?>
            <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
                <div class="bg-white p-6 rounded-md w-96">
                    <h2 class="text-xl font-bold mb-4">Dinas Keluar</h2>
                    <textarea wire:model="deskripsi_dinas" class="w-full p-2 border rounded-md"
                        placeholder="Masukkan keterangan dinas keluar..."></textarea>
                    <div class="mt-4 flex justify-end gap-2">
                        <button wire:click="$set('showDinasModal', false)"
                            class="px-4 py-2 bg-gray-400 text-white rounded-md hover:bg-gray-500">Batal</button>
                        <button wire:click="dinasKeluar"
                            class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Simpan</button>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if($showOvertimeModal): ?>
            <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
                <div class="bg-white p-6 rounded-md w-96">
                    <h2 class="text-xl font-bold mb-4">Lembur</h2>
                    <textarea wire:model.live="deskripsi_lembur" class="w-full p-2 border rounded-md"
                        placeholder="Masukkan keterangan lembur..."></textarea>
                    <div class="mt-4 flex justify-end gap-2">
                        <button wire:click="$set('showOvertimeModal', false)"
                            class="px-4 py-2 bg-gray-400 text-white rounded-md hover:bg-gray-500">
                            Batal
                        </button>
                        <button wire:click="saveOvertime"
                            class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                            Simpan Lembur
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($showLemburModal): ?>
            <div class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
                <div class="bg-white p-6 rounded-md w-96">
                    <h2 class="text-xl font-bold mb-4">Mulai Lembur</h2>
                    <textarea wire:model.defer="deskripsi_lembur" class="w-full p-2 border rounded-md"
                        placeholder="Masukkan deskripsi lembur..."></textarea>
                    <div class="mt-4 flex justify-end gap-2">
                        <button wire:click="$set('showLemburModal', false)"
                            class="px-4 py-2 bg-gray-400 text-white rounded-md hover:bg-gray-500">
                            Batal
                        </button>
                        <button wire:click="startLemburMandiri"
                            class="px-4 py-2 bg-yellow-500 text-white rounded-md hover:bg-yellow-700">
                            Simpan
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php $__env->startPush('scripts'); ?>
            <script type="module">
                window.addEventListener('alert-error', event => {

                    // Ambil langsung dari event.detail.message
                    const message = event.detail.message;

                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: message,
                        showConfirmButton: false,
                        timer: 1500
                    });
                });

                window.addEventListener('alert-success', event => {

                    // Ambil langsung dari event.detail.message
                    const message = event.detail.message;

                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil...',
                        text: message,
                        showConfirmButton: false,
                        timer: 1500
                    });
                });
            </script>
        <?php $__env->stopPush(); ?>
    </div>
    <?php $__env->startPush('scripts'); ?>
        
        <script type="module">
            let timer;
            let timeElapsed = 0;
            let isRunning = false;
            let isStopped = false;

            let timerLembur;
            let timeElapsedLembur = 0;
            let isLemburRunning = false;

            function updateTimerDisplay() {
                const days = Math.floor(timeElapsed / 86400); // 1 hari = 86400 detik
                const hours = Math.floor((timeElapsed % 86400) / 3600).toString().padStart(2, '0');
                const minutes = Math.floor((timeElapsed % 3600) / 60).toString().padStart(2, '0');
                const seconds = (timeElapsed % 60).toString().padStart(2, '0');

                const display = document.getElementById('timerDisplay');

                if (days > 0) {
                    // Jika sudah lebih dari 24 jam → Tampilkan format dengan hari
                    display.innerText = `${days}d ${hours}:${minutes}:${seconds}`;
                } else {
                    // Jika masih dalam 24 jam → Format HH:mm:ss
                    display.innerText = `${hours}:${minutes}:${seconds}`;
                }

                // Efek tampilan jika timer berhenti
                if (isStopped) {
                    display.classList.add('text-gray-600', 'opacity-50');
                } else {
                    display.classList.remove('text-gray-600', 'opacity-50');
                }
            }

            // Fungsi untuk memulai timer
            function startTimer(startTimestamp) {
                if (!isRunning) {
                    isRunning = true;
                    isStopped = false;
                    // Jika startTimestamp kosong → mulai dari 0
                    timeElapsed = startTimestamp ?
                        Math.floor(Date.now() / 1000) - startTimestamp :
                        0;

                    updateTimerDisplay();

                    timer = setInterval(() => {
                        timeElapsed++;
                        updateTimerDisplay();
                    }, 1000);
                }
            }

            // Jika timer utama sudah berhenti → Hitung selisih langsung di frontend
            if (!<?php echo json_encode($isRunning, 15, 512) ?> && <?php echo json_encode($timeOut, 15, 512) ?>) {
                const startTime = new Date(<?php echo json_encode($timeIn, 15, 512) ?> * 1000); // Konversi ke milidetik
                const endTime = new Date(<?php echo json_encode($timeOut, 15, 512) ?> * 1000); // Konversi ke milidetik

                // ✅ Hitung selisih kerja utama dalam detik
                timeElapsed = Math.floor((endTime - startTime) / 1000);

                // ✅ Jika ada lembur → Tambahkan ke hasil akhir
                if (<?php echo json_encode($timeInLembur, 15, 512) ?> && <?php echo json_encode($timeOutLembur, 15, 512) ?>) {
                    const lemburStart = new Date(<?php echo json_encode($timeInLembur, 15, 512) ?> * 1000);
                    const lemburEnd = new Date(<?php echo json_encode($timeOutLembur, 15, 512) ?> * 1000);

                    // Hitung selisih waktu lembur
                    const lemburElapsed = Math.floor((lemburEnd - lemburStart) / 1000);

                    // ✅ Gabungkan hasil lembur ke hasil utama
                    timeElapsed += lemburElapsed;
                }

                isRunning = false;
                isStopped = true;

                updateTimerDisplay();

                // Efek visual saat timer berhenti
                const display = document.getElementById('timerDisplay');
                display.classList.add('text-gray-600', 'opacity-50');
            }

            function updateLemburDisplay() {
                const hours = Math.floor(timeElapsedLembur / 3600).toString().padStart(2, '0');
                const minutes = Math.floor((timeElapsedLembur % 3600) / 60).toString().padStart(2, '0');
                const seconds = (timeElapsedLembur % 60).toString().padStart(2, '0');

                const display = document.getElementById('lemburDisplay');
                if (display) {
                    display.innerText = `${hours}:${minutes}:${seconds}`;
                }
            }


            function startLemburTimer(startTimestamp) {
                if (!isLemburRunning) {
                    isLemburRunning = true;

                    // ✅ Hitung selisih waktu lembur dari `startTimestamp`
                    timeElapsedLembur = startTimestamp ?
                        Math.floor(Date.now() / 1000) - startTimestamp :
                        0;

                    updateLemburDisplay();

                    // ✅ Jalankan timer lembur setiap detik
                    timerLembur = setInterval(() => {
                        timeElapsedLembur++;
                        updateLemburDisplay();
                    }, 1000);
                }
            }

            // Update timer lembur berdasarkan data `timeInLembur` dari backend
            if (<?php echo json_encode($isLemburRunning, 15, 512) ?> && <?php echo json_encode($timeInLembur, 15, 512) ?>) {
                const lemburStart = new Date(<?php echo json_encode($timeInLembur, 15, 512) ?> * 1000); // Convert from seconds to milliseconds
                const currentTime = new Date();
                const lemburDuration = Math.floor((currentTime - lemburStart) / 1000); // Calculate elapsed time

                timeElapsedLembur = lemburDuration;
                updateLemburDisplay();
            }


            function stopLemburTimer() {
                isLemburRunning = false;
            }

            // Tangkap event dari Livewire untuk memulai timer
            window.addEventListener('timer-started', (event) => {
                const startTimestamp = event.detail;

                if (!isRunning) {
                    timeElapsed = Math.floor(Date.now() / 1000) - startTimestamp;
                    timer = setInterval(() => {
                        timeElapsed++;
                        updateTimerDisplay();
                    }, 1000);
                }
            });

            // Event untuk memulai timer lembur dari Livewire
            window.addEventListener('timer-lembur-started', (event) => {
                startLemburTimer(event.detail);
            });

            window.addEventListener('timer-lembur-stopped', () => {
                stopLemburTimer();
            });

            // Jika sudah ada `timeIn` dan status berjalan → Mulai otomatis
            if (<?php echo json_encode($isRunning, 15, 512) ?> && <?php echo json_encode($timeIn, 15, 512) ?>) {
                // console.log('Timer Resumed:', <?php echo json_encode($timeIn, 15, 512) ?>);
                startTimer(<?php echo json_encode($timeIn, 15, 512) ?>);
            }

            // ✅ Jika timer lembur sudah berjalan → Mulai otomatis
            if (<?php echo json_encode($isLemburRunning, 15, 512) ?> && <?php echo json_encode($timeInLembur, 15, 512) ?>) {
                console.log(<?php echo json_encode($timeInLembur, 15, 512) ?>);
                startLemburTimer(<?php echo json_encode($timeInLembur, 15, 512) ?>);
            }
        </script>
    <?php $__env->stopPush(); ?>
    
    <h3 class="font-bold mt-4">RENCANA KERJA</h3>
    <p class="font-semibold text-gray-600"><?php echo e($this->absensiTanpaLembur->first()->deskripsi_in ?? '-'); ?></p>

    
    <!--[if BLOCK]><![endif]--><?php if(!empty($this->absensiTanpaLembur->first()->deskripsi_out)): ?>
        <h3 class="font-bold mt-4">SELESAI KERJA</h3>
        <p class="font-semibold text-gray-600"><?php echo e($this->absensiTanpaLembur->first()->deskripsi_out ?? '-'); ?></p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH D:\File's Niko\Kerjaan\RSISimpeg\resources\views/livewire/timer.blade.php ENDPATH**/ ?>