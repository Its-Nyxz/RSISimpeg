<!DOCTYPE html>
<html lang="en">
<?php if (isset($component)) { $__componentOriginal781d22988f835a9692410092c1d21cd6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal781d22988f835a9692410092c1d21cd6 = $attributes; } ?>
<?php $component = App\View\Components\Head::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Head::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $attributes = $__attributesOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__attributesOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $component = $__componentOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__componentOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>


<body class="min-h-screen bg-no-repeat bg-center bg-cover"
    style="background-image: url('<?php echo e(asset('img/bg-login.png')); ?>');">
    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('navbar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1487605468-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('sidebar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1487605468-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <div class="container ps-10 pt-[7rem] sm:ps-[20rem] max-w-[90%] sm:max-w-[96%] md:max-w-[98%] text-gray-800">
        <?php echo e($slot); ?>

    </div>
    <?php echo $__env->yieldPushContent('html'); ?>
</body>

<?php if(session('success')): ?>
    <script type="module">
        feedback('Berhasil', "<?php echo e(session('success')); ?>", 'success');
    </script>
<?php endif; ?>
<?php if(session('error')): ?>
    <script type="module">
        feedback('Gagal', "<?php echo e(session('error')); ?>", 'error');
    </script>
<?php endif; ?>
<?php echo $__env->yieldPushContent('scripts'); ?>

</html>
<?php /**PATH D:\File's Niko\Kerjaan\RSISimpeg\resources\views/components/layout/body.blade.php ENDPATH**/ ?>