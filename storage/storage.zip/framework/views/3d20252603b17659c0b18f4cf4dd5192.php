<?php if (isset($component)) { $__componentOriginalad23403a0cc5b038de74a0be6fcb2c57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad23403a0cc5b038de74a0be6fcb2c57 = $attributes; } ?>
<?php $component = App\View\Components\Body::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Body::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('data-jabatan', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3354847785-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad23403a0cc5b038de74a0be6fcb2c57)): ?>
<?php $attributes = $__attributesOriginalad23403a0cc5b038de74a0be6fcb2c57; ?>
<?php unset($__attributesOriginalad23403a0cc5b038de74a0be6fcb2c57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad23403a0cc5b038de74a0be6fcb2c57)): ?>
<?php $component = $__componentOriginalad23403a0cc5b038de74a0be6fcb2c57; ?>
<?php unset($__componentOriginalad23403a0cc5b038de74a0be6fcb2c57); ?>
<?php endif; ?>

<?php /**PATH D:\File's Niko\Kerjaan\RSISimpeg\resources\views/jabatan/index.blade.php ENDPATH**/ ?>