<div class="mb-4">
    <div class="py-2 mb-3">
        <h1 class="text-2xl font-bold text-success-900">Data Karyawan</h1>
    </div>
    <div class="flex flex-col md:flex-row justify-between items-center md:gap-4 space-y-3 md:space-y-0 mb-3">
        <!-- Bagian Dropdown -->
        <div id="1" class="flex space-x-4 w-full md:w-auto justify-center md:justify-start">
            <select wire:model.live="selectedUserAktif"
                class="rounded-lg px-2 py-2 border border-gray-300 focus:ring-2 focus:ring-success-600">
                <option value="1">Aktif</option>
                <option value="0">Non Aktif</option>
            </select>
            <!--[if BLOCK]><![endif]--><?php if(auth()->user()->hasRole('Super Admin') || auth()->user()->unitKerja->nama == 'KEPEGAWAIAN'): ?>
                <select wire:model.live="selectedUnit"
                    class="rounded-lg px-2 py-2 border border-gray-300 focus:ring-2 focus:ring-success-600">
                    <option value="">-- Pilih Unit --</option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <select wire:model.live="selectedJenisKaryawan"
                class="rounded-lg px-2 py-2 border border-gray-300 focus:ring-2 focus:ring-success-600">
                <option value="">-- Semua Jenis Karyawan --</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $jenisKaryawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>

        <!-- Bagian Search dan Tambah (Tetap dalam satu baris) -->
        <div id="2" class="flex w-full md:w-auto items-center gap-3 md:gap-4">
            <!--[if BLOCK]><![endif]--><?php if(auth()->user()->hasRole('Super Admin') || auth()->user()->unitKerja->nama == 'KEPEGAWAIAN'): ?>
                <a href="<?php echo e(route('datakaryawan.export')); ?>" target="_blank"
                    class="text-green-900 bg-green-100 hover:bg-green-600 hover:text-white font-medium rounded-lg text-sm px-5 py-2.5 transition duration-200"
                    data-tooltip-target="tooltip-export-karyawan">
                    <i class="fas fa-file-excel"></i>
                </a>
                <div id="tooltip-export-karyawan" role="tooltip"
                    class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip">
                    Export Template Karyawan
                    <div class="tooltip-arrow" data-popper-arrow></div>
                </div>

                <div x-data="{ open: false }">
                    <!-- Tombol Import -->
                    <button @click="open = true"
                        class="text-blue-900 bg-blue-100 hover:bg-blue-600 hover:text-white font-medium rounded-lg text-sm px-5 py-2.5 transition duration-200"
                        data-tooltip-target="tooltip-import-karyawan">
                        <i class="fas fa-upload"></i>
                    </button>

                    <!-- Tooltip -->
                    <div id="tooltip-import-karyawan" role="tooltip"
                        class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip">
                        Import Data Karyawan
                        <div class="tooltip-arrow" data-popper-arrow></div>
                    </div>

                    <!-- Modal Upload -->
                    <div x-show="open" @keydown.escape.window="open = false"
                        class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
                        <div class="bg-white p-6 rounded-lg w-full max-w-md shadow-lg">
                            <h2 class="text-lg font-semibold mb-4">Import Data Karyawan</h2>

                            <form action="<?php echo e(route('datakaryawan.import')); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="file" name="file" id="fileInput" accept=".xlsx"
                                    class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer focus:outline-none">
                                <p class="text-sm text-gray-500 mt-1">Hanya file <strong>template_karyawan.xlsx</strong>
                                    yang diterima</p>

                                <div class="mt-4 flex justify-end gap-2">
                                    <button type="button" @click="open = false"
                                        class="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">Batal</button>
                                    <button type="submit"
                                        class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Import</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <input type="text" wire:keyup="updateSearch($event.target.value)" placeholder="Cari Karyawan..."
                class="flex-1 md:w-auto rounded-lg px-4 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-success-600" />
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-data-karyawan')): ?>
                <a href="<?php echo e(route('datakaryawan.create')); ?>"
                    class="text-success-900 bg-success-100 hover:bg-success-600 hover:text-white font-medium rounded-lg text-sm px-5 py-2.5 transition duration-200 whitespace-nowrap">
                    + Tambah Karyawan
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
        <table class="w-full text-sm text-center text-gray-700">
            <thead class="text-sm uppercase bg-success-400 text-success-900">
                <tr>
                    <th scope="col" class="px-6 py-3">Nama</th>
                    <th scope="col" class="px-6 py-3">NIP</th>
                    <th scope="col" class="px-6 py-3">Alamat</th>
                    <th scope="col" class="px-6 py-3">Jabatan</th>
                    <th scope="col" class="px-6 py-3">Unit</th>
                    <th scope="col" class="px-6 py-3">Detail</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="odd:bg-success-50 even:bg-success-100 border-b border-success-300 hover:bg-success-300">
                        <td scope="row" class="px-6 py-4 font-medium text-success-900 whitespace-nowrap">
                            <?php echo e($user->name); ?>

                        </td>
                        <td class="px-6 py-4"><?php echo e($user->nip ?? '-'); ?></td>
                        <td class="px-6 py-4"><?php echo e($user->alamat ?? '-'); ?></td>
                        <td class="px-6 py-4">
                            <?php echo e($user->kategorifungsional && $user->kategorijabatan
                                ? $user->kategorijabatan->nama . ' + ' . $user->kategorifungsional->nama
                                : $user->kategorijabatan->nama ?? '-'); ?>

                        </td>
                        <td class="px-6 py-4"><?php echo e($user->unitKerja->nama ?? '-'); ?></td>
                        <td class="px-6 py-4">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('detail-data-karyawan')): ?>
                                <a href="<?php echo e(route('detailkaryawan.show', ['detailkaryawan' => $user->id])); ?>"
                                    class="bg-green-700 text-white font-medium rounded-md px-3 py-2 hover:bg-green-800 focus:ring-4 focus:outline-none focus:ring-green-300">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center px-6 py-4">Tidak ada data Karyawan.</td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>
    <div class="mt-4 flex gap-2 justify-center items-center">
        
        <!--[if BLOCK]><![endif]--><?php if(!$users->onFirstPage()): ?>
            <button wire:click="previousPage" wire:loading.attr="disabled"
                class="px-2 py-1 bg-success-100 hover:bg-success-600 text-success-900 rounded-md text-sm">
                &laquo; Sebelumnya
            </button>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <?php
            $totalPages = $users->lastPage();
            $currentPage = $users->currentPage();
            $range = 3; // Range around current page
        ?>

        
        <!--[if BLOCK]><![endif]--><?php if($currentPage > $range + 1): ?>
            <button wire:click="gotoPage(1)"
                class="px-2 py-1 bg-success-100 hover:bg-success-600 text-success-900 rounded-md text-sm">
                1
            </button>
            <!--[if BLOCK]><![endif]--><?php if($currentPage > $range + 2): ?>
                <span class="px-2 py-1 text-gray-500">...</span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php for($page = max($currentPage - $range, 1); $page <= min($currentPage + $range, $totalPages); $page++): ?>
            <!--[if BLOCK]><![endif]--><?php if($page == $currentPage): ?>
                <span class="px-2 py-1 bg-success-600 text-white rounded-md text-sm"><?php echo e($page); ?></span>
            <?php else: ?>
                <button wire:click="gotoPage(<?php echo e($page); ?>)"
                    class="px-2 py-1 bg-success-100 hover:bg-success-600 text-success-900 rounded-md text-sm">
                    <?php echo e($page); ?>

                </button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if($currentPage < $totalPages - $range): ?>
            <!--[if BLOCK]><![endif]--><?php if($currentPage < $totalPages - $range - 1): ?>
                <span class="px-2 py-1 text-gray-500">...</span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <button wire:click="gotoPage(<?php echo e($totalPages); ?>)"
                class="px-2 py-1 bg-success-100 hover:bg-success-600 text-success-900 rounded-md text-sm">
                <?php echo e($totalPages); ?>

            </button>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if($users->hasMorePages()): ?>
            <button wire:click="nextPage" wire:loading.attr="disabled"
                class="px-2 py-1 bg-success-100 hover:bg-success-600 text-success-900 rounded-md text-sm">
                Selanjutnya &raquo;
            </button>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH D:\File's Niko\Kerjaan\RSISimpeg\resources\views/livewire/data-karyawan.blade.php ENDPATH**/ ?>