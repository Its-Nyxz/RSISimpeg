<?php if (isset($component)) { $__componentOriginalad23403a0cc5b038de74a0be6fcb2c57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad23403a0cc5b038de74a0be6fcb2c57 = $attributes; } ?>
<?php $component = App\View\Components\Body::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Body::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-success-900">
            DASHBOARD <?php echo e(auth()->user()->unitKerja->nama ?? ' '); ?>

        </h1>

        
        <?php if(count($masaBerlakuSipStr) > 0): ?>
            <div
                class="flex items-center bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 px-4 py-2 rounded-lg text-sm max-w-2xl overflow-y-auto max-h-28">
                <div>
                    <p class="font-bold mb-1">PERHATIAN: Masa Berlaku SIP/STR</p>
                    <ul class="list-disc list-inside space-y-1">
                        <?php $__currentLoopData = $masaBerlakuSipStr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $selesai = \Carbon\Carbon::parse($file->selesai);
                                $sisaHari = intval(now()->diffInDays($selesai));

                            ?>
                            <li>
                                <?php if(auth()->user()->unitKerja?->nama === 'KEPEGAWAIAN' || auth()->user()->hasRole('Super Admin')): ?>
                                    <strong><?php echo e($file->user->name ?? '-'); ?></strong> -
                                <?php endif; ?>

                                <?php echo e($file->jenisFile->name ?? '-'); ?>

                                berakhir <strong><?php echo e($selesai->format('d M Y')); ?></strong>

                                
                                <?php if($sisaHari <= 7): ?>
                                    <span class="ml-2 text-red-600 font-bold">(Sisa <?php echo e($sisaHari); ?> Hari!)</span>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <!-- Kolom Kiri (Lebih Besar) -->
        <div class="md:col-span-2">
            <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $attributes; } ?>
<?php $component = App\View\Components\Card::resolve(['title' => 'Timer'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('timer', ['jadwalId' => $jadwal_id,'jadwal_id' => $jadwal_id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1975506593-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $attributes = $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
        </div>
        <!-- Kolom Kanan -->
        <div class="md:col-span-1">
            
            <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $attributes; } ?>
<?php $component = App\View\Components\Card::resolve(['title' => 'Detail'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
                <div class="flex flex-col gap-4 p-4">
                    <div class="flex justify-between">
                        <div class="font-semibold">Sisa Cuti Tahunan</div>
                        <div><?php echo e($sisaCutiTahunan); ?> kali</div>
                    </div>
                    <div class="flex justify-between">
                        <div class="font-semibold">Keterlambatan Per Bulan</div>
                        <div><?php echo e($jumlahKeterlambatan); ?> kali </div>
                    </div>
                    <div class="font-semibold">
                        Izin :
                    </div>
                    <div class="ml-4 flex flex-col gap-2">
                        <div class="flex justify-between">
                            <div>Sakit</div>
                            <div><?php echo e($jumlahIzin['sakit']); ?> kali</div>
                        </div>
                        <div class="flex justify-between">
                            <div>Tugas</div>
                            <div><?php echo e($jumlahIzin['tugas']); ?> kali</div>
                        </div>
                        <div class="flex justify-between">
                            <div>Keluarga</div>
                            <div><?php echo e($jumlahIzin['keluarga']); ?> kali</div>
                        </div>
                        <div class="flex justify-between">
                            <div>Tanpa Keterangan</div>
                            <div><?php echo e($jumlahTanpaKeterangan); ?> kali</div>
                        </div>
                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $attributes = $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>


            <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $attributes; } ?>
<?php $component = App\View\Components\Card::resolve(['title' => 'Pengajuan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
                <div class="flex flex-row items-left gap-x-4 overflow-x-auto" style="margin-left: 30px;">
                    <!-- ✅ Tombol Cuti -->
                    <div class="text-left">
                        <a href="<?php echo e(route('pengajuan.create', ['tipe' => 'cuti'])); ?>"
                            class="inline-flex items-center px-5 py-3 text-white font-medium rounded-full shadow-md
                                bg-green-500 hover:bg-green-400 transition-all duration-300 transform hover:-translate-y-1">
                            Cuti
                            <i class="fa-solid fa-circle-chevron-right ml-2" style="color: #ffffff;"></i>
                        </a>
                    </div>

                    <!-- ✅ Tombol Ijin -->
                    <div class="text-left">
                        <a href="<?php echo e(route('pengajuan.create', ['tipe' => 'ijin'])); ?>"
                            class="inline-flex items-center px-5 py-3 text-white font-medium rounded-full shadow-md
                                bg-blue-500 hover:bg-blue-400 transition-all duration-300 transform hover:-translate-y-1">
                            Ijin
                            <i class="fa-solid fa-circle-chevron-right ml-2" style="color: #ffffff;"></i>
                        </a>
                    </div>

                    <!-- ✅ Tombol Tukar Jadwal -->
                    <div class="text-left">
                        <a href="<?php echo e(route('pengajuan.create', ['tipe' => 'tukar_jadwal'])); ?>"
                            class="inline-flex items-center px-5 py-3 text-white font-medium rounded-full shadow-md
                                bg-yellow-500 hover:bg-yellow-400 transition-all duration-300 transform hover:-translate-y-1">
                            Tukar Jadwal
                            <i class="fa-solid fa-circle-chevron-right ml-2" style="color: #ffffff;"></i>
                        </a>
                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $attributes = $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>

        </div>

    </div>
    <div>
        <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $attributes; } ?>
<?php $component = App\View\Components\Card::resolve(['title' => 'Jadwal Absen'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('data-jadwal', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1975506593-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $attributes = $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad23403a0cc5b038de74a0be6fcb2c57)): ?>
<?php $attributes = $__attributesOriginalad23403a0cc5b038de74a0be6fcb2c57; ?>
<?php unset($__attributesOriginalad23403a0cc5b038de74a0be6fcb2c57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad23403a0cc5b038de74a0be6fcb2c57)): ?>
<?php $component = $__componentOriginalad23403a0cc5b038de74a0be6fcb2c57; ?>
<?php unset($__componentOriginalad23403a0cc5b038de74a0be6fcb2c57); ?>
<?php endif; ?>
<?php /**PATH D:\File's Niko\Kerjaan\RSISimpeg\resources\views/dashboard/index.blade.php ENDPATH**/ ?>