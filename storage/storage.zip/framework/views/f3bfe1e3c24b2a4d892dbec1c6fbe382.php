<div>
    
    
    <div class="flex justify-between items-center gap-4 mb-2">
        <div>
            <!--[if BLOCK]><![endif]--><?php if(auth()->user()->hasRole('Super Admin') || auth()->user()->unitKerja->nama == 'KEPEGAWAIAN'): ?>
                <!-- Input Pencarian -->
                <select wire:model.live="selectedUnit"
                    class="rounded-lg px-4 py-2 border border-gray-300 focus:ring-2 focus:ring-success-600">>
                    <option value="">Pilih Unit</option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if(collect(auth()->user()->roles()->pluck('name'))->filter(function ($name) {
                        return str_starts_with($name, 'Kepala');
                    })->count()): ?>
                <select wire:model.live="selectedUser"
                    class="rounded-lg px-4 py-2 border border-gray-300 focus:ring-2 focus:ring-success-600">
                    <option value="">All</option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="flex justify-end items-center gap-3 mb-2">
            <!--[if BLOCK]><![endif]--><?php if($routeIsDashboard): ?>
                <div class="flex justify-end">
                    <div>
                        <a href="<?php echo e(route('jadwal.index')); ?>"
                            class="text-success-900 bg-success-100 hover:bg-success-600 hover:text-white font-medium rounded-lg text-sm px-5 py-2.5 transition duration-200"
                            data-tooltip-target="tooltip-pengaturan">
                            <i class="fa-solid fa-gear"></i>
                        </a>
                        <div id="tooltip-pengaturan" role="tooltip"
                            class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip">
                            Pengaturan Jadwal Absensi
                            <div class="tooltip-arrow" data-popper-arrow></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if(!$routeIsDashboard): ?>
                <div class="flex justify-end">
                    <div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tambah-jadwal')): ?>
                            <!-- Tombol Tambah Jadwal -->
                            <a href="<?php echo e(route('jadwal.create')); ?>"
                                class="text-success-900 bg-success-100 hover:bg-success-600 hover:text-white font-medium rounded-lg text-sm px-5 py-2.5 transition duration-200">
                                <i class="fa-solid fa-plus"></i> Tambah Jadwal
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!-- Tombol Keterangan Shift -->
            <button type="button" wire:click="openShiftModal"
                class="text-success-900 bg-success-100 hover:bg-success-600 hover:text-white font-medium rounded-lg text-sm px-5 py-2.5 transition duration-200"
                data-tooltip-target="tooltip-keterangan-shift">
                <i class="fa-solid fa-circle-info"></i>
            </button>
            <div id="tooltip-keterangan-shift" role="tooltip"
                class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip">
                Lihat Keterangan Shift
                <div class="tooltip-arrow" data-popper-arrow></div>
            </div>

        </div>


    </div>
    

    <!-- Filter Bulan & Tahun -->
    <div class="flex gap-4 mb-4">
        <select wire:model.live="bulan"
            class="rounded-lg px-4 py-2 border border-gray-300 focus:ring-2 focus:ring-success-600">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($m); ?>"><?php echo e(DateTime::createFromFormat('!m', $m)->format('F')); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </select>

        <select wire:model.live="tahun"
            class="rounded-lg px-4 py-2 border border-gray-300 focus:ring-2 focus:ring-success-600">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = range(now()->year - 5, now()->year); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($y); ?>"><?php echo e($y); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </select>



        <!--[if BLOCK]><![endif]--><?php if(!$routeIsDashboard): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('template-jadwal')): ?>
                <!-- Tombol Download Template -->
                <a href="<?php echo e(route('jadwal.template', ['month' => $bulan, 'year' => $tahun])); ?>"
                    class="text-success-900 bg-success-100 hover:bg-success-600 hover:text-white font-medium rounded-lg text-sm px-5 py-2.5 transition duration-200">
                    <i class="fas fa-download"></i> Download Template
                </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('import-jadwal')): ?>
                <!-- Input untuk Import -->
                <input type="file" wire:model="file" class="hidden" id="uploadFile">
                <button type="button" onclick="document.getElementById('uploadFile').click();"
                    class="text-success-900 bg-success-100 hover:bg-success-600 hover:text-white font-medium rounded-lg text-sm px-5 py-2.5 transition duration-200">
                    <i class="fas fa-file-excel"></i> Import Excel
                </button>

                <!-- Menampilkan Nama File -->
                <!--[if BLOCK]><![endif]--><?php if($file): ?>
                    <div class="mt-2 flex items-center space-x-2">
                        <span class="text-sm text-green-700 font-medium"><?php echo e($file->getClientOriginalName()); ?></span>

                        <!-- Tombol Hapus File -->
                        <button type="button" wire:click="$set('file', null)"
                            class="text-red-500 hover:text-red-700 font-medium text-sm">
                            <i class="fas fa-times-circle"></i>
                        </button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <!-- Menampilkan Progress Upload -->
                <div wire:loading wire:target="file" class="mt-2">
                    <div class="w-full bg-gray-200 rounded-full">
                        <div class="bg-green-500 text-xs leading-none py-1 text-center text-white" style="width: 0%;"
                            x-data="{ progress: 0 }" x-init="$watch('progress', value => {
                                setInterval(() => {
                                    if (progress < 100) progress += 10;
                                }, 200);
                            })">
                            Loading...
                        </div>
                    </div>
                </div>

                <!-- Tombol Submit Import -->
                <!--[if BLOCK]><![endif]--><?php if($file): ?>
                    <button type="button" wire:click="import"
                        class="mt-2 text-success-900 bg-success-100 hover:bg-success-600 hover:text-white font-medium rounded-lg text-sm px-5 py-2.5 transition duration-200">
                        Submit Import
                    </button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </div>
    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    <div class="relative overflow-auto max-h-full shadow-md rounded-lg">
        <table class="w-full text-sm text-left text-gray-700">
            <thead class="text-sm uppercase bg-success-400 text-success-900">
                <tr>
                    <th class="px-4 py-3">Nama</th>
                    <th class="px-4 py-3">Pendidikan</th>
                    <th class="px-4 py-3">Tanggal Masuk</th>
                    <th class="px-4 py-3">Lama Kerja</th>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tanggalJadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanggal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $carbonDate = \Carbon\Carbon::parse($tanggal);
                            $hari = $carbonDate->format('l'); // Nama Hari
                            $isHoliday = $this->isHoliday($tanggal);
                        ?>
                        <th
                            class="px-2 py-3 text-center
                            <?php echo e($isHoliday ? 'bg-red-500 text-white' : ''); ?>">
                            <?php echo e($carbonDate->format('d')); ?>

                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-jadwal')): ?>
                        <th class="px-4 py-3">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>

            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_id => $jadwalUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd:bg-success-50 even:bg-success-100 border-b border-success-300 hover:bg-success-300">
                        <td class="px-4 py-3 font-medium text-success-900 whitespace-nowrap">
                            <?php echo e(optional(optional($jadwalUser)->first())->user->name ?? '-'); ?>

                        </td>
                        <td class="px-4 py-3">
                            <?php echo e(optional(optional($jadwalUser)->first())->user->pendidikanUser->nama ?? '-'); ?>

                        </td>
                        <td class="px-4 py-3">
                            <?php echo e(optional(optional($jadwalUser)->first())->user->tmt ? \Carbon\Carbon::parse(optional(optional($jadwalUser)->first())->user->tmt)->format('d M Y') : '-'); ?>

                        </td>
                        <td class="px-4 py-3">
                            <?php
                                $user = optional(optional($jadwalUser)->first())->user;
                                $masaKerja = $user?->masa_kerja;
                                $jenis = strtolower($user?->jenis?->nama ?? '');
                            ?>

                            <?php echo e($masaKerja !== null ? ($jenis === 'kontrak' ? floor($masaKerja) . ' bulan' : $masaKerja . ' tahun') : '-'); ?>

                        </td>

                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tanggalJadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanggal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $shiftData = $filteredShifts[$user_id][$tanggal] ?? null;
                                $isSpecialShift = in_array($shiftData['nama_shift'] ?? '', ['I', 'C']);
                            ?>

                            <td
                                class="px-2 py-3 text-center
                        <?php echo e($isHoliday || $isSpecialShift ? 'bg-red-200 text-red-600' : ($hari === 'Sunday' ? 'bg-red-200 text-red-600' : '')); ?>">

                                <!--[if BLOCK]><![endif]--><?php if($shiftData): ?>
                                    <button
                                        wire:click="showShiftDetail('<?php echo e($shiftData['nama_shift']); ?>', '<?php echo e($shiftData['jam_masuk']); ?>', '<?php echo e($shiftData['jam_keluar']); ?>', `<?php echo e($shiftData['keterangan'] ?? '-'); ?>`)"
                                        class="hover:text-blue-700 hover:underline transition duration-150">
                                        <?php echo e($shiftData['nama_shift'] ?? '-'); ?>

                                    </button>
                                <?php else: ?>
                                    -
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-jadwal')): ?>
                            <td class="px-4 py-3">
                                <a href="<?php echo e(route('jadwal.edit', optional(optional($jadwalUser)->first())->user->id)); ?>"
                                    class="text-success-900 px-3 py-2 rounded-md border hover:bg-slate-300"
                                    data-tooltip-target="tooltip-jadwalUser-<?php echo e(optional(optional($jadwalUser)->first())->user->id); ?>">
                                    <i class="fa-solid fa-pen"></i>
                                </a>
                                <div id="tooltip-jadwalUser-<?php echo e(optional(optional($jadwalUser)->first())->user->id); ?>"
                                    role="tooltip"
                                    class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip">
                                    Ubah Data Jadwal Absensi
                                    <div class="tooltip-arrow" data-popper-arrow></div>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>
    <!--[if BLOCK]><![endif]--><?php if($showModalShift): ?>
        <div class="fixed inset-0 bg-gray-800 bg-opacity-50 flex justify-center items-center z-50">
            <div class="bg-white rounded-lg shadow-lg w-3/4 max-h-[80vh] overflow-auto p-6">
                <h2 class="text-lg font-semibold mb-4">Keterangan Shift per Unit</h2>

                <table class="w-full text-sm border border-gray-300">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="border p-2">Unit</th>
                            <th class="border p-2">Kode Shift</th>
                            <th class="border p-2">Jam Masuk</th>
                            <th class="border p-2">Jam Pulang</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $dataShifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="border p-2"><?php echo e($shift->unitKerja->nama ?? '-'); ?></td>
                                <td class="border p-2"><?php echo e($shift->nama_shift); ?></td>
                                <td class="border p-2"><?php echo e($shift->jam_masuk); ?></td>
                                <td class="border p-2"><?php echo e($shift->jam_keluar); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>

                <div class="mt-4 text-right">
                    <button wire:click="closeShiftModal"
                        class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600">Tutup</button>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if($showModalDetailShift): ?>
        <div class="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center px-4">
            <div class="bg-white rounded-lg shadow-xl w-full max-w-md sm:max-w-lg p-6 relative overflow-hidden">

                <!-- Judul -->
                <h2 class="text-lg sm:text-xl font-semibold mb-4 text-center">Detail Shift</h2>

                <!-- Isi Modal -->
                <div class="text-sm sm:text-base text-gray-700 space-y-2">
                    <div><strong>Nama Shift:</strong> <?php echo e($shiftNama); ?></div>
                    <div><strong>Jam:</strong> <?php echo e($shiftJamMasuk); ?> - <?php echo e($shiftJamKeluar); ?></div>
                    <div><strong>Keterangan:</strong> <?php echo e($shiftKeterangan ?? '-'); ?></div>
                </div>

                <!-- Tombol Tutup -->
                <div class="mt-6 text-center">
                    <button wire:click="$set('showModalDetailShift', false)"
                        class="bg-red-600 hover:bg-red-700 text-white px-5 py-2 rounded-lg transition duration-200">
                        Tutup
                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH D:\File's Niko\Kerjaan\RSISimpeg\resources\views/livewire/data-jadwal.blade.php ENDPATH**/ ?>