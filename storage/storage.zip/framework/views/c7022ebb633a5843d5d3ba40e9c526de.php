<header class="z-40 sm:z-50 fixed w-full">
    <nav class="bg-gradient-to-r from-yellow-300 via-green-500 to-green-700 text-white px-4 py-4 shadow-xl">
        
        <div class="flex flex-wrap justify-between items-center mx-3">
            <div class="flex">
                <button data-drawer-target="default-sidebar" data-drawer-toggle="default-sidebar"
                    aria-controls="default-sidebar" type="button"
                    class="inline-flex items-center p-2 text-md hover:text-success-100 ml-3 me-1 transition duration-100 text-success-950 rounded-lg sm:hidden hover:bg-success-700 focus:outline-none focus:ring-2 focus:ring-gray-200 ">
                    <span class="sr-only">Open sidebar</span>
                    <i class="fa-solid fa-bars"></i>
                </button>
                <a href="/" class="flex items-center">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" class="mr-3 h-6 sm:h-9 hidden sm:flex" alt="Logo" />
                    <span
                        class="self-center text-[1.2rem] sm:text-xl font-bold whitespace-nowrap text-success-950">SIMPEG
                        <span class="font-medium">RSI
                            BANJARNEGARA</span></span>
                </a>
            </div>
            <div class="flex items-center">
                <!-- ✅ Nama dan Foto Profil Disembunyikan di Mobile -->
                <div class="hidden sm:flex items-center ">
                    <!-- Nama Profil -->
                    <span class="font-medium text-white me-2" style="text-transform: capitalize;">
                        <?php echo e(auth()->user()->name); ?>

                    </span>
                    <!-- Foto Profil -->
                    <a href="<?php echo e(route('userprofile.index')); ?>"
                        class="text-white bg-success-950 rounded-full me-2 hover:bg-gray-100 transition duration-150 hover:text-success-950 px-1 py-1">
                        <?php echo auth()->user()->photo
                            ? '<img src="' .
                                asset('storage/photos/' . auth()->user()->photo) .
                                '" 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            alt="Profile" 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            class="w-8 h-8 rounded-full object-cover border border-gray-300">'
                            : '<div class="w-8 h-8 flex items-center justify-center bg-gray-200 rounded-full border border-gray-300">
                                                                                                                                                                                                                                                                                                                                                                                                                            <i class="fa-solid fa-user"></i>
                                                                                                                                                                                                                                                                                                                                                                                                                            </div>'; ?>

                    </a>
                </div>

                <div class="relative inline-block mr-2">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('notification', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1825916050-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>

                <!-- ✅ Tombol Logout Tetap Muncul di Mobile -->
                <div class="flex items-center">
                    <a href="<?php echo e(route('logout')); ?>"
                        class="text-white bg-success-950 rounded-full hover:bg-gray-100 hover:text-success-950 px-3 py-2">
                        <i class="fa-solid fa-arrow-right-from-bracket"></i>
                    </a>
                </div>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH D:\File's Niko\Kerjaan\RSISimpeg\resources\views/livewire/navbar.blade.php ENDPATH**/ ?>