<div>
    <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $attributes; } ?>
<?php $component = App\View\Components\Card::resolve(['title' => 'Hak Akses & Perizinan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="flex justify-between items-center gap-4 mb-3">
            <p>Pengaturan untuk Hak Akses dan Perizinan yang dapat diakses.</p>

            <a href="#"
                class="text-success-900 bg-success-100 hover:bg-success-600 hover:text-white font-medium rounded-lg text-sm px-5 py-2.5 transition duration-200">
                + Buat Hak Akses
            </a>
        </div>

        <div class="flex-1" style="margin-bottom: 20px;">
            <input type="text" wire:keyup="updateSearch($event.target.value)" placeholder="Cari Hak Akses..."
                class="w-full rounded-lg px-4 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-success-600" />
        </div>

        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $jabatanperizinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if (isset($component)) { $__componentOriginal71612112ea436bfdb2dfd060fccb7254 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71612112ea436bfdb2dfd060fccb7254 = $attributes; } ?>
<?php $component = App\View\Components\CardTanpaTitle::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-tanpa-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CardTanpaTitle::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
                <div class="flex justify-between items-center ">
                    <p><?php echo e($item['name']); ?></p>

                    <div class="flex justify-between items-center gap-2">
                        <button type="button" class="text-success-900 px-3 py-2 rounded-md border hover:bg-slate-300"
                            wire:click="editJabatan(<?php echo e($item['id']); ?>)"
                            data-tooltip-target="tooltip-item-<?php echo e($item['id']); ?>"
                            @click="$dispatch('open-modal', 'edit-modal', '<?php echo e($item['id']); ?>')">

                            <i class="fa-solid fa-pen"></i>
                        </button>
                        <a href="<?php echo e(route('detail.show', ['detail' => $item['id']])); ?>"
                            class="text-success-900 px-3 py-2 rounded-md border hover:bg-slate-300">
                            <i class="fa-solid fa-eye"></i>
                        </a>

                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71612112ea436bfdb2dfd060fccb7254)): ?>
<?php $attributes = $__attributesOriginal71612112ea436bfdb2dfd060fccb7254; ?>
<?php unset($__attributesOriginal71612112ea436bfdb2dfd060fccb7254); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71612112ea436bfdb2dfd060fccb7254)): ?>
<?php $component = $__componentOriginal71612112ea436bfdb2dfd060fccb7254; ?>
<?php unset($__componentOriginal71612112ea436bfdb2dfd060fccb7254); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>

                <td colspan="3" class="text-center px-6 py-4">Tidak ada data Jabatan.</td>

            </tr>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $attributes = $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>



    <!-- Modal -->

    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'edit-modal','maxWidth' => 'lg','show' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'edit-modal','maxWidth' => 'lg','show' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>

        <form class="mx-5 py-5" wire:submit.prevent="updateJabatan">

            <h2 class="text-lg font-semibold mb-4">Edit Jabatan</h2>

            <div class="mb-4">

                <label for="jabatan_nama" class="block text-sm font-medium text-gray-700">Nama Jabatan</label>

                <input type="text" id="jabatan_nama" wire:model="jabatanNama"
                    class="w-full rounded-lg px-4 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-success-600"
                    placeholder="Nama Jabatan">

            </div>

            <div class="flex justify-end space-x-4">

                <button type="button" x-on:click="$dispatch('close-modal', 'edit-modal')"
                    class="px-4 py-2 bg-gray-200 rounded-lg">Batal</button>

                <button type="submit" class="px-4 py-2 bg-success-600 text-white rounded-lg">Simpan</button>

            </div>

        </form>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>


</div>
<?php /**PATH D:\File's Niko\Kerjaan\RSISimpeg\resources\views/livewire/data-jabatan-perizinan.blade.php ENDPATH**/ ?>