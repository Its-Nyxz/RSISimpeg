<div id="dropdownNotificationButton" data-dropdown-toggle="dropdownNotification" data-dropdown-trigger="hover"
    class="text-white bg-success-950 rounded-full hover:bg-gray-100 hover:text-success-950 px-3 py-2 transition duration-200 uppercase relative">

    <!-- Wrapper Ikon Bell dan Badge -->
    <div class="relative inline-block">
        <!-- Ikon Bell -->
        <i class="fas fa-bell"></i>

        <!--[if BLOCK]><![endif]--><?php if(auth()->user()->unreadNotifications->count() > 0): ?>
            <!-- Badge untuk jumlah notifikasi -->
            <span
                class="absolute -top-4 right-2  bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                <?php echo e(auth()->user()->unreadNotifications->count()); ?>

            </span>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <!-- Dropdown Notifikasi -->
    <div id="dropdownNotification" class="z-10 hidden bg-white shadow-2xl max-w-lg w-96 ">

        <ul class="font-normal text-sm text-gray-700 capitalize max-h-60 w-full overflow-y-auto"
            aria-labelledby="dropdownNotificationButton">

            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = auth()->user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="appearance-none list-none"> <!-- ✅ Tambahkan list-none di sini -->
                    <div wire:click="markAsRead('<?php echo e($notification->id); ?>','<?php echo e($notification->data['url']); ?>')"
                        class="flex cursor-pointer group justify-between px-4 py-3 hover:bg-success-950 transition duration-200 hover:text-white ">

                        <!-- Isi Notifikasi -->
                        <div><?php echo $notification->data['message']; ?></div>

                        <!-- Status "Baru" -->
                        <div>
                            <!--[if BLOCK]><![endif]--><?php if(!$notification->read_at): ?>
                                <span class="text-xs text-green-500 group-hover:text-white font-semibold ml-2">
                                    Baru
                                </span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="px-4 py-3 text-gray-500 text-sm text-center list-none"> <!-- ✅ Tambahkan list-none -->
                    Tidak ada notifikasi
                </li>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    </div>
</div>
<?php /**PATH D:\File's Niko\Kerjaan\RSISimpeg\resources\views/livewire/notification.blade.php ENDPATH**/ ?>